(function(m, o, n, t, e, r, _){
r = o.createElement(n);_ = o.getElementsByTagName(n)[0];r.async = 1;r.src = t;r.setAttribute('crossorigin', 'use-credentials');_.parentNode .insertBefore(r, _);
})(window, document, 'script', 'https://an.gr-wcon.com/script/5b77e824-c6fa-4977-8879-4bf807f25057/ga.js');