(function() {
    window._grpr = {"_v":"2.1.0","nativePrompt":null,"customPrompts":[],"paths":[]};
})();